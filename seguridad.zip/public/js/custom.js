$(document).ready(function(){
  console.log('I am ready!');
  $('.tooltip-info [data-toggle="tooltip"]').tooltip();
  console.log('I am finished!');
});