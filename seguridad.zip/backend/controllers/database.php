<?php 
		$mysqli = new MySQLi("localhost", "root","viveros", "aseguridad");
?>