<?php
    echo '<section id="breadcrumb">
    <div class="container">
      <ol class="breadcrumb">
        <li class="active">
          <a href="index.html">Dashboard</a>
        </li>
      </ol>
    </div>
  </section>';
?>

